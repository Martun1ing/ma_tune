import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../../core/utils/token_manager.dart';
import 'playlist_detail_screen.dart';

class PlaylistScreen extends StatefulWidget {
  const PlaylistScreen({super.key});

  @override
  _PlaylistScreenState createState() => _PlaylistScreenState();
}

class _PlaylistScreenState extends State<PlaylistScreen> {
  List<dynamic> playlists = [];
  bool isLoading = true;
  bool hasError = false;

  @override
  void initState() {
    super.initState();
    fetchPlaylists();
  }

  Future<void> fetchPlaylists() async {
    final tokenInfo = await TokenManager.getToken();
    if (tokenInfo != null) {
      final response = await http.get(
        Uri.parse('http://localhost:5000/playlists'),
        headers: {
          'Authorization': 'Bearer ${tokenInfo['accessToken']}',
        },
      );

      if (response.statusCode == 200) {
        setState(() {
          playlists = json.decode(response.body)['items'];
          isLoading = false;
        });
      } else {
        setState(() {
          hasError = true;
          isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Vos Playlists'),
        ),
        body: const Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    if (hasError) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Erreur'),
        ),
        body: const Center(
          child: Text('Erreur lors de la récupération des playlists.'),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Vos Playlists Spotify'),
      ),
      body: ListView.builder(
        itemCount: playlists.length,
        itemBuilder: (context, index) {
          final playlist = playlists[index];
          return ListTile(
            title: Text(playlist['name']),
            subtitle: Text('${playlist['tracks']['total']} titres'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => PlaylistDetailScreen(
                    playlistId: playlist['id'],
                    playlistName: playlist['name'],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
