import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:io';
import 'package:permission_handler/permission_handler.dart';
import 'package:path_provider/path_provider.dart';
import 'package:file_picker/file_picker.dart';

import '../../core/utils/storage_manager.dart';
import '../../core/utils/token_manager.dart';

class PlaylistDetailScreen extends StatefulWidget {
  final String playlistId;
  final String playlistName;

  const PlaylistDetailScreen({
    Key? key,
    required this.playlistId,
    required this.playlistName,
  }) : super(key: key);

  @override
  _PlaylistDetailScreenState createState() => _PlaylistDetailScreenState();
}

class _PlaylistDetailScreenState extends State<PlaylistDetailScreen> {
  List<dynamic> tracks = [];
  bool isLoading = true;
  bool hasError = false;
  String? selectedDirectoryPath;

  @override
  void initState() {
    super.initState();
    fetchPlaylistDetails();
  }

  Future<void> fetchPlaylistDetails() async {
    final tokenInfo = await TokenManager.getToken();
    if (tokenInfo != null) {
      final response = await http.get(
        Uri.parse('http://localhost:5000/playlists/${widget.playlistId}'),
        headers: {
          'Authorization': 'Bearer ${tokenInfo['accessToken']}',
        },
      );

      if (response.statusCode == 200) {
        setState(() {
          tracks = json.decode(response.body)['tracks']['items'];
          isLoading = false;
        });
      } else {
        setState(() {
          hasError = true;
          isLoading = false;
        });
      }
    }
  }

  Future<String> getMusicDirectoryPath() async {
    final storedPath = await StorageManager.getDownloadFolderPath();
    if (storedPath != null) {
      return storedPath;
    }

    if (Platform.isAndroid) {
      return '/storage/emulated/0/Music';
    } else if (Platform.isIOS) {
      final directory = await getApplicationDocumentsDirectory();
      return directory.path;
    } else if (Platform.isLinux || Platform.isWindows || Platform.isMacOS) {
      final directory = await getDirectoryPathFromPicker();
      if (directory != null) {
        await StorageManager.setDownloadFolderPath(directory); // Sauvegarder le chemin sélectionné
        return directory;
      }
      return (await getApplicationDocumentsDirectory()).path;
    } else {
      throw UnsupportedError('Cette plateforme n\'est pas supportée.');
    }
  }

  Future<String?> getDirectoryPathFromPicker() async {
    return await FilePicker.platform.getDirectoryPath();
  }

  Future<bool> isTrackDownloaded(String title, String artist) async {
    final musicDirectory = await getMusicDirectoryPath();
    final filePath = '$musicDirectory/$title - $artist.mp3';
    return File(filePath).existsSync();  // Vérifie si le fichier existe dans le répertoire
  }

  Future<void> downloadTrack(
      String title, String artist, String album, String imageUrl) async {
    if (await Permission.storage.request().isGranted) {
      final response = await http.post(
        Uri.parse('http://localhost:5000/download'),
        headers: {
          'Content-Type': 'application/json',
        },
        body: json.encode({
          'title': title,
          'artist': artist,
          'album': album,
          'image_url': imageUrl,
        }),
      );

      if (response.statusCode == 200) {
        final musicDirectory = await getMusicDirectoryPath();

        final filePath = '$musicDirectory/$title - $artist.mp3';
        final file = File(filePath);
        await file.writeAsBytes(response.bodyBytes);

        setState(() {});  // Re-render pour mettre à jour l'icône
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Téléchargement terminé et stocké en local !')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Échec du téléchargement.')),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Permission de stockage refusée.')),
      );
    }
  }

  Future<void> downloadPlaylist() async {
    if (await Permission.storage.request().isGranted) {
      final musicDirectory = await getMusicDirectoryPath();
      int totalTracks = tracks.length;
      int downloadedTracks = 0;

      for (final track in tracks) {
        final title = track['track']['name'];
        final artist = track['track']['artists'][0]['name'];

        // Vérifier si la piste est déjà téléchargée
        final fileExists = await isTrackDownloaded(title, artist);

        if (!fileExists) {
          final album = track['track']['album']['name'];
          final imageUrl = track['track']['album']['images'][0]['url'];

          final response = await http.post(
            Uri.parse('http://localhost:5000/download'),
            headers: {
              'Content-Type': 'application/json',
            },
            body: json.encode({
              'title': title,
              'artist': artist,
              'album': album,
              'image_url': imageUrl,
            }),
          );

          if (response.statusCode == 200) {
            final filePath = '$musicDirectory/$title - $artist.mp3';
            final file = File(filePath);
            await file.writeAsBytes(response.bodyBytes);

            // Mettre à jour le compteur
            setState(() {
              downloadedTracks++;
            });

            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Téléchargement terminé pour $title')),
            );
          } else {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Échec du téléchargement pour $title')),
            );
          }
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('$title - $artist est déjà téléchargé.')),
          );
        }

        // Affichage de la progression
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Téléchargement: $downloadedTracks/$totalTracks')),
        );
      }

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Téléchargement de la playlist terminé !')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Permission de stockage refusée.')),
      );
    }
  }


  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return Scaffold(
        appBar: AppBar(
          title: Text(widget.playlistName),
        ),
        body: const Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    if (hasError) {
      return Scaffold(
        appBar: AppBar(
          title: Text(widget.playlistName),
        ),
        body: const Center(
          child: Text('Erreur lors de la récupération des détails de la playlist.'),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.playlistName),
        actions: [
          IconButton(
            icon: const Icon(Icons.download),
            onPressed: downloadPlaylist, // Lancer le téléchargement de la playlist complète
          ),
          IconButton(
            icon: const Icon(Icons.folder_open),
            onPressed: () async {
              String? selectedPath = await getDirectoryPathFromPicker();
              if (selectedPath != null) {
                setState(() {
                  selectedDirectoryPath = selectedPath;
                });
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Dossier sélectionné : $selectedPath')),
                );
              }
            },
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: tracks.length,
        itemBuilder: (context, index) {
          final track = tracks[index]['track'];
          final title = track['name'];
          final artist = track['artists'][0]['name'];

          return FutureBuilder<bool>(
            future: isTrackDownloaded(title, artist),
            builder: (context, snapshot) {
              final isDownloaded = snapshot.data ?? false;

              return ListTile(
                title: Text(title),
                subtitle: Text(artist),
                trailing: isDownloaded
                    ? const Icon(Icons.check_circle, color: Colors.green)  // V vert si téléchargé
                    : IconButton(
                  icon: const Icon(Icons.download),
                  onPressed: () {
                    downloadTrack(
                      title,
                      artist,
                      track['album']['name'],
                      track['album']['images'][0]['url'],
                    );
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}
