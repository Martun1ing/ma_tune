import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:ma_tune/core/utils/token_manager.dart';
import 'package:shelf/shelf.dart' as shelf;
import 'package:shelf/shelf_io.dart' as shelf_io;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:url_launcher/url_launcher.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  LoginScreenState createState() => LoginScreenState();
}

class LoginScreenState extends State<LoginScreen> {
  bool isLoading = false;
  final _storage = const FlutterSecureStorage();

  @override
  void initState() {
    super.initState();
  }

  startLocalServer() async {
    final handler = const shelf.Pipeline()
        .addMiddleware(shelf.logRequests())
        .addHandler(_handleRequest);

    // Démarre le serveur local sur le port 8080
    final server = await shelf_io.serve(handler, 'localhost', 8080);
    print('Server running on localhost:${server.port}');
  }

  Future<shelf.Response> _handleRequest(shelf.Request request) async {
    if (request.url.path == 'callback') {
      final params = request.url.queryParameters;
      final accessToken = params['access_token'];
      final refreshToken = params['refresh_token'];
      final expiresAt = params['expires_at'];

      if (accessToken != null && refreshToken != null) {
        await TokenManager.saveToken(accessToken, refreshToken, jsonDecode(expiresAt!));

        // Rediriger ou mettre à jour l'interface utilisateur
        Navigator.pushReplacementNamed(context, '/playlists');

        return shelf.Response.ok('Tokens received. You can now close this window.');
      } else {
        return shelf.Response(400, body: 'Tokens not found.');
      }
    }
    return shelf.Response.notFound('Page not found');
  }

  Future<void> loginWithSpotify() async {
    setState(() {
      isLoading = true;
    });
    await startLocalServer();
    // Lancer l'authentification via le backend
    final url = Uri.parse('http://localhost:5000/login');

    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    } else {
      throw Exception('Impossible de lancer $url');
    }

    setState(() {
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Connexion à Spotify'),
      ),
      body: Center(
        child: isLoading
            ? const CircularProgressIndicator()
            : ElevatedButton(
          onPressed: loginWithSpotify,
          child: const Text('Se connecter avec Spotify'),
        ),
      ),
    );
  }
}
