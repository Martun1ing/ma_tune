import 'package:flutter/material.dart';
import '../features/authentication/login_screen.dart';
import '../features/playlists/playlist_screen.dart';
import '../core/constants/app_routes.dart';

class AppRouter {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case AppRoutes.login:
        return MaterialPageRoute(builder: (_) => const LoginScreen());
      case AppRoutes.playlists:
        return MaterialPageRoute(builder: (_) => const PlaylistScreen());
      default:
        return MaterialPageRoute(
          builder: (_) => Scaffold(
            body: Center(child: Text('Route not found')),
          ),
        );
    }
  }
}
