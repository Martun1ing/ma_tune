import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class StorageManager {
  static const _storage = FlutterSecureStorage();
  static const _folderKey = 'download_folder_path';
  static const _downloadedTracksKey = 'downloaded_tracks';

  // Sauvegarde le chemin du dossier de téléchargement
  static Future<void> setDownloadFolderPath(String path) async {
    await _storage.write(key: _folderKey, value: path);
  }

  // Récupère le chemin du dossier de téléchargement
  static Future<String?> getDownloadFolderPath() async {
    return await _storage.read(key: _folderKey);
  }

  // Sauvegarde les informations de téléchargement d'une piste
  static Future<void> saveDownloadedTrack(String trackId, String path) async {
    final allTracks = await getDownloadedTracks() ?? {};
    allTracks[trackId] = path;
    await _storage.write(key: _downloadedTracksKey, value: json.encode(allTracks));
  }

  // Récupère les informations des pistes téléchargées
  static Future<Map<String, String>?> getDownloadedTracks() async {
    final tracksString = await _storage.read(key: _downloadedTracksKey);
    if (tracksString != null) {
      return Map<String, String>.from(json.decode(tracksString));
    }
    return null;
  }
}
