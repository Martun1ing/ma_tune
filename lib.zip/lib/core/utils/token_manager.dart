import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class TokenManager {
  static const _storage = FlutterSecureStorage();

  static Future<void> saveToken(String accessToken, String refreshToken, int expiresAt) async {
    await _storage.write(key: 'accessToken', value: accessToken);
    await _storage.write(key: 'refreshToken', value: refreshToken);
    await _storage.write(key: 'expiresAt', value: expiresAt.toString());
  }

  static Future<Map<String, dynamic>?> getToken() async {
    String? accessToken = await _storage.read(key: 'accessToken');
    String? refreshToken = await _storage.read(key: 'refreshToken');
    String? expiresAtStr = await _storage.read(key: 'expiresAt');

    if (accessToken != null && refreshToken != null && expiresAtStr != null) {
      int expiresAt = int.parse(expiresAtStr);
      return {
        'accessToken': accessToken,
        'refreshToken': refreshToken,
        'expiresAt': expiresAt,
      };
    }
    return null;
  }

  static Future<void> clearToken() async {
    await _storage.delete(key: 'accessToken');
    await _storage.delete(key: 'refreshToken');
    await _storage.delete(key: 'expiresAt');
  }
}
