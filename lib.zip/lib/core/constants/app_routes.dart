class AppRoutes {
  static const String login = '/login';
  static const String playlists = '/playlists';
  static const String home = '/home';
}
